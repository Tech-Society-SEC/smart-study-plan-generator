# Smart Study Plan Generator — Streamlit Prototype

This directory contains a working Streamlit prototype converted from your Jupyter notebook.

Files:
- app.py : Streamlit app
- requirements.txt : Python packages required

## Run locally
1. Create a virtual environment and activate it.
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   streamlit run app.py
   ```

## Deploy to Streamlit Community Cloud
1. Create a new GitHub repository and push this folder (app.py and requirements.txt).
2. Go to https://streamlit.io/cloud and sign in with GitHub.
3. Create a new app, choose the repository and branch, and set `app.py` as the main file.
4. Click Deploy — Streamlit will install dependencies and launch the site. Provide any required secrets via the 'Secrets' panel if needed.

## Notes and next steps I can implement for you
- Add a trained neural network (DNN) to predict recommended study hours based on student features.
- Improve scheduler to allocate fractional hours and respect per-subject constraints and preferred time slots.
- Add calendar export (.ics) and Google Calendar integration.
- Add persistent user accounts (Firebase) and save/load plans.
- Add better visualizations and explanations for recommendations.